Student name: Junyao Cui  
Student ID: 1527740

Reference for this assignment:
1. Generating all combinations of a list in python: https://stackoverflow.com/questions/17434070/generating-all-combinations-of-a-list-in-python
2. Using Regular exprission to remove unnessary character: https://stackoverflow.com/questions/27938765/replace-non-alphanumeric-characters-except-some-exceptions-python

For this assignment, I worked by myself.