Student name: Junyao Cui  
Student ID: 1527740

For this assignment, I worked with Yingxian Zhou 1549852