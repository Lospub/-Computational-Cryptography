Student name: Junyao Cui  
Student ID: 1527740

Reference for this assignment:
1. Code from the text book: https://www.nostarch.com/crackingcodes/ (BSD Licensed)
2. Usage of Counter: https://docs.python.org/3/library/collections.html#collections.Counter

For this assignment, I worked with (Student name Student ID): Yingxian Zhou 1549852 for problem 3