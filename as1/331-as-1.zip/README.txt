Student name: Junyao Cui  
Student ID: 1527740

For this assignment 1 the only reference I used is the "caesarCipher.py" file. Here is the citation from caesarCipher.py: http://inventwithpython.com/hacking (BSD Licensed)


For the short answer questions, I worked with (Student name Student ID): Zihong Ni 1506628, Xiyuan Shen 1506660, Yingxian Zhou 1549852

