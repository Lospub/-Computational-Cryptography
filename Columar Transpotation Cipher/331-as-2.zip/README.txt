Student name: Junyao Cui  
Student ID: 1527740

For this assignment 2 the reference I used are transpositionEncrypt.py and transpositionDecrypt.py. Here are the citation from the file:  https://www.nostarch.com/crackingcodes/ (BSD Licensed)

I also checked for building the 2d array:
 https://stackoverflow.com/questions/2397141/how-to-initialize-a-two-dimensional-array-in-python

Add string in a certain position in Python:
https://stackoverflow.com/questions/5254445/add-string-in-a-certain-position-in-python


For this assignment, I worked with (Student name Student ID): Yingxian Zhou 1549852