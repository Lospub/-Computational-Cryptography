Student name: Junyao Cui  
Student ID: 1527740

Reference for this assignment:
1. Code from the text book: https://www.nostarch.com/crackingcodes/ (BSD Licensed)
2. sort list:
https://www.programiz.com/python-programming/methods/list/sort



For this assignment, I worked by myself.