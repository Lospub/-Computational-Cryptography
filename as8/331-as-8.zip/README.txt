Student name: Junyao Cui  
Student ID: 1527740

Reference for this assignment:
1. Code from the text book: https://www.nostarch.com/crackingcodes/ (BSD Licensed)
2. itertools.product:
https://docs.python.org/3/library/itertools.html#itertools.combinations
3. Check ascii:
https://www.kite.com/python/answers/how-to-check-if-a-string-is-in-ascii-in-python



For this assignment, I worked by myself.