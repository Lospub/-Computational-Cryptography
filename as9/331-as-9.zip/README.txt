Student name: Junyao Cui  
Student ID: 1527740

Reference for this assignment:
1. Code from the text book: https://www.nostarch.com/crackingcodes/ (BSD Licensed)
2. find prime factor:
https://stackoverflow.com/questions/43129076/prime-factorization-of-a-number



For this assignment, I worked by myself.