Student name: Junyao Cui  
Student ID: 1527740

Reference for this assignment:
1. Euclidean algorithm: https://algorithmist.com/wiki/Euclidean_algorithm
2. Extended Euclidean algorithm: https://algorithmist.com/wiki/Extended_Euclidean_algorithm
3. Modular inverse: https://algorithmist.com/wiki/Modular_inverse

For this assignment, I worked with (Student name Student ID): Yingxian Zhou 1549852