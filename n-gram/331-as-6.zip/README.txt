Student name: Junyao Cui  
Student ID: 1527740

Reference for this assignment:
1. Code from the text book: https://www.nostarch.com/crackingcodes/ (BSD Licensed)
2. Usage of itertools: https://docs.python.org/3.8/library/itertools.html#itertools.combinations


For this assignment, I worked with (Student name Student ID): Yingxian Zhou 1549852